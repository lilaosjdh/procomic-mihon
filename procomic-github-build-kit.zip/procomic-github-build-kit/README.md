# ProComic Mihon extension - GitHub build kit

This repository is a small phone-friendly build kit for the Arabic ProComic source.

It contains the source module under `src/ar/procomic` and a GitHub Actions workflow.
When you push/commit it to a GitHub repository, open **Actions → Build ProComic extension → Run workflow**.
The workflow checks out the current Keiyoushi extension build system, inserts this module, and attempts to build the APK.

Important: this kit is a build source, not itself a Mihon extension repository index. A Mihon extension store requires a built APK plus repository metadata (`index.json`/`index.min.json` or the current protobuf index). The APK artifact produced by Actions can be installed manually in Mihon-compatible Android environments.

The source intentionally does not bypass paid/coin-locked chapters or authentication.
