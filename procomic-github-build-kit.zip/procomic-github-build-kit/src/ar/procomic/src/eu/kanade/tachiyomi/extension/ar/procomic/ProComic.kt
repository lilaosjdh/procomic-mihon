package eu.kanade.tachiyomi.extension.ar.procomic

import eu.kanade.tachiyomi.network.GET
import eu.kanade.tachiyomi.source.model.FilterList
import eu.kanade.tachiyomi.source.model.MangasPage
import eu.kanade.tachiyomi.source.model.Page
import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.SManga
import eu.kanade.tachiyomi.source.online.HttpSource
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.decodeFromStream
import okhttp3.Request
import okhttp3.Response
import java.text.SimpleDateFormat
import java.util.Locale

class ProComic : HttpSource() {

    override val name = "ProComic"
    override val baseUrl = "https://procomic.pro"
    override val lang = "ar"
    override val supportsLatest = true

    private val json = Json { ignoreUnknownKeys = true }
    private val dateFormat =
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)

    override fun headersBuilder() = super.headersBuilder()
        .add("Referer", "$baseUrl/")
        .add("Origin", baseUrl)
        .add("Accept-Language", "ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7")
        .add(
            "User-Agent",
            "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
        )

    private fun contentRequest(page: Int, query: String = ""): Request {
        val q = if (query.isBlank()) "" else "&q=${java.net.URLEncoder.encode(query, "UTF-8")}"
        return GET(
            "$baseUrl/api/public/content/latest-updates?limit=30&category=comics&page=$page$q",
            headers,
        )
    }

    override fun popularMangaRequest(page: Int) = contentRequest(page)

    override fun latestUpdatesRequest(page: Int) = contentRequest(page)

    override fun searchMangaRequest(
        page: Int,
        query: String,
        filters: FilterList,
    ) = contentRequest(page, query)

    override fun popularMangaParse(response: Response): MangasPage {
        val data = response.parseAs<LatestUpdatesResponse>()
        val mangas = data.data
            .filter { it.type != "novel" }
            .map { it.toSManga() }
        return MangasPage(mangas, mangas.size >= 30)
    }

    override fun latestUpdatesParse(response: Response) =
        popularMangaParse(response)

    override fun searchMangaParse(response: Response) =
        popularMangaParse(response)

    override fun mangaDetailsRequest(manga: SManga): Request {
        val p = manga.url.split("/")
        return GET("$baseUrl/api/public/${p.getOrElse(0) { "manga" }}/${p.getOrElse(1) { "0" }}", headers)
    }

    override fun mangaDetailsParse(response: Response): SManga {
        val data = response.parseAs<SeriesDetailResponse>()
        val parts = response.request.url.pathSegments
        val idx = parts.indexOf("public")
        return SManga.create().apply {
            url = "${parts.getOrElse(idx + 1) { "manga" }}/${parts.getOrElse(idx + 2) { "0" }}/${data.slug.orEmpty()}"
            title = data.title.orEmpty()
            thumbnail_url =
                data.coverImageApp?.card?.mobile
                    ?: data.coverImageApp?.desktop
                    ?: data.coverImage
            author = data.author
            artist = data.artist
            description = data.synopsis ?: data.description
            status = when (data.status?.lowercase()) {
                "ongoing", "مستمر" -> SManga.ONGOING
                "completed", "مكتمل" -> SManga.COMPLETED
                "hiatus" -> SManga.ON_HIATUS
                else -> SManga.UNKNOWN
            }
        }
    }

    override fun chapterListRequest(manga: SManga): Request {
        val p = manga.url.split("/")
        return GET(
            "$baseUrl/api/public/${p.getOrElse(0) { "manga" }}/${p.getOrElse(1) { "0" }}/chapters?page=1&limit=500&order=desc",
            headers,
        )
    }

    override fun chapterListParse(response: Response): List<SChapter> {
        val parts = response.request.url.pathSegments
        val idx = parts.indexOf("public")
        val seriesType = parts.getOrElse(idx + 1) { "manga" }
        val seriesId = parts.getOrElse(idx + 2) { "0" }

        return response.parseAs<ChaptersResponse>().data.map { ch ->
            SChapter.create().apply {
                url = "$seriesType/$seriesId/${ch.id}/${ch.chapterNumber}"
                name = "الفصل ${ch.chapterNumber}" +
                    if (!ch.title.isNullOrBlank()) " - ${ch.title}" else ""
                date_upload = runCatching {
                    dateFormat.parse(ch.publishedAt.orEmpty())?.time
                }.getOrNull() ?: 0L
                chapter_number = ch.chapterNumber.toFloatOrNull() ?: 0f
                scanlator = if (ch.lockedByCoins == true) "🔒 مدفوع" else null
            }
        }
    }

    override fun pageListRequest(chapter: SChapter): Request {
        val p = chapter.url.split("/")
        return GET(
            "$baseUrl/api/public/${p.getOrElse(0) { "manga" }}/${p.getOrElse(1) { "0" }}/chapters" +
                "?page=1&limit=500&order=desc&_cid=${p.getOrElse(2) { "0" }}",
            headers.newBuilder().set("Accept", "application/json").build(),
        )
    }

    override fun pageListParse(response: Response): List<Page> {
        val chapterId = response.request.url.queryParameter("_cid") ?: return emptyList()
        val data = response.parseAs<ChaptersResponse>()
        val chapter = data.data.firstOrNull { it.id.toString() == chapterId } ?: return emptyList()
        val cdn = "https://${chapter.cdnPath ?: "cdn1"}.procomic.pro"

        // Public, directly exposed chapter images.
        // Locked/obfuscated media is intentionally not bypassed.
        return chapter.metadata?.images.orEmpty().mapIndexed { index, path ->
            Page(index, imageUrl = if (path.startsWith("http")) path else "$cdn$path")
        }
    }

    override fun imageUrlParse(response: Response) = ""

    private inline fun <reified T> Response.parseAs(): T =
        json.decodeFromStream(body.byteStream())
}

@Serializable
data class LatestUpdatesResponse(
    val success: Boolean = false,
    val data: List<SeriesDto> = emptyList(),
)

@Serializable
data class SeriesDto(
    @SerialName("mangaId") val id: Int = 0,
    @SerialName("mangaSlug") val slug: String = "",
    @SerialName("mangaTitle") val title: String = "",
    val coverImage: String? = null,
    val type: String = "manga",
    val coverImageApp: CoverImageApp? = null,
) {
    fun toSManga() = SManga.create().apply {
        url = "$type/$id/$slug"
        title = this@SeriesDto.title
        thumbnail_url =
            coverImageApp?.card?.mobile
                ?: coverImageApp?.desktop
                ?: coverImage
    }
}

@Serializable
data class CoverImageApp(
    val desktop: String? = null,
    val card: CardImages? = null,
)

@Serializable
data class CardImages(
    val mobile: String? = null,
    val desktop: String? = null,
)

@Serializable
data class SeriesDetailResponse(
    val id: Int = 0,
    val title: String? = null,
    val slug: String? = null,
    val coverImage: String? = null,
    val coverImageApp: CoverImageApp? = null,
    val author: String? = null,
    val artist: String? = null,
    val description: String? = null,
    val synopsis: String? = null,
    val status: String? = null,
)

@Serializable
data class ChaptersResponse(
    val data: List<ChapterDto> = emptyList(),
    val total: Int = 0,
)

@Serializable
data class ChapterDto(
    val id: Int = 0,
    @SerialName("chapter_number") val chapterNumber: String = "0",
    val title: String? = null,
    @SerialName("published_at") val publishedAt: String? = null,
    val lockedByCoins: Boolean? = null,
    @SerialName("cdn_path") val cdnPath: String? = null,
    val metadata: ChapterMetadataDto? = null,
)

@Serializable
data class ChapterMetadataDto(
    val images: List<String> = emptyList(),
)
