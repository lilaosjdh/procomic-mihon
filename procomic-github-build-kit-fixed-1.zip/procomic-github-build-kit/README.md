# ProComic Mihon GitHub Build Kit (Keiyoushi 1.6)

This replaces the old legacy Gradle setup. It targets the current Keiyoushi extension build system and KeiSource 1.6.

Use the `.github/workflows/build-procomic.yml` workflow to build the APK with GitHub Actions.
