package eu.kanade.tachiyomi.extension.ar.procomic

import eu.kanade.tachiyomi.source.model.FilterList
import eu.kanade.tachiyomi.source.model.MangasPage
import eu.kanade.tachiyomi.source.model.Page
import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.SManga
import eu.kanade.tachiyomi.source.model.SMangaUpdate
import keiyoushi.annotation.Source
import keiyoushi.network.get
import keiyoushi.source.KeiSource
import keiyoushi.utils.parseAs
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import okhttp3.Headers
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import java.time.Instant

@Source
abstract class ProComic : KeiSource() {

    override fun Headers.Builder.configureHeaders() = apply {
        add("Accept-Language", "ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7")
    }

    override suspend fun getPopularManga(page: Int): MangasPage = getContent(page)

    override suspend fun getLatestUpdates(page: Int): MangasPage = getContent(page)

    override suspend fun getSearchMangaList(
        page: Int,
        query: String,
        filters: FilterList,
    ): MangasPage = getContent(page, query)

    private suspend fun getContent(page: Int, query: String = ""): MangasPage {
        val url = "$baseUrl/api/public/content/latest-updates".toHttpUrl().newBuilder()
            .addQueryParameter("limit", "30")
            .addQueryParameter("category", "comics")
            .addQueryParameter("page", page.toString())
            .apply {
                if (query.isNotBlank()) addQueryParameter("q", query)
            }
            .build()

        return client.get(url).use { response ->
            val data = response.parseAs<LatestUpdatesResponse>().data
                .filter { it.type != "novel" }
                .map { it.toSManga() }
            MangasPage(data, data.size >= 30)
        }
    }

    override suspend fun getMangaByUrl(url: HttpUrl): SManga? {
        val parts = url.pathSegments
        val seriesIndex = parts.indexOf("series")
        if (seriesIndex == -1 || seriesIndex + 2 >= parts.size) return null

        val type = parts[seriesIndex + 1]
        val id = parts[seriesIndex + 2]
        return fetchDetails(type, id)
    }

    override fun getMangaUrl(manga: SManga): String = "$baseUrl/ar/series/${manga.url}"

    override fun getChapterUrl(chapter: SChapter): String {
        val p = chapter.url.split("/")
        return "$baseUrl/ar/series/${p.getOrElse(0) { "manga" }}/${p.getOrElse(1) { "0" }}/${p.getOrElse(2) { "0" }}/${p.getOrElse(3) { "0" }}"
    }

    override suspend fun fetchMangaUpdate(
        manga: SManga,
        chapters: List<SChapter>,
        fetchDetails: Boolean,
        fetchChapters: Boolean,
    ): SMangaUpdate {
        val parts = manga.url.split("/")
        val type = parts.getOrElse(0) { "manga" }
        val id = parts.getOrElse(1) { "0" }

        val updatedManga = if (fetchDetails) fetchDetails(type, id) ?: manga else manga
        val updatedChapters = if (fetchChapters) fetchChapters(type, id) else chapters
        return SMangaUpdate(updatedManga, updatedChapters)
    }

    override suspend fun getPageList(chapter: SChapter): List<Page> {
        val p = chapter.url.split("/")
        val type = p.getOrElse(0) { "manga" }
        val seriesId = p.getOrElse(1) { "0" }
        val chapterId = p.getOrElse(2) { "0" }

        val url = "$baseUrl/api/public/$type/$seriesId/chapters"
            .toHttpUrl().newBuilder()
            .addQueryParameter("page", "1")
            .addQueryParameter("limit", "500")
            .addQueryParameter("order", "desc")
            .addQueryParameter("_cid", chapterId)
            .build()

        return client.get(url).use { response ->
            val chapterDto = response.parseAs<ChaptersResponse>().data
                .firstOrNull { it.id.toString() == chapterId }
                ?: return@use emptyList()

            val cdn = "https://${chapterDto.cdnPath ?: "cdn1"}.procomic.pro"
            chapterDto.metadata?.images.orEmpty().map { path ->
                Page(0, imageUrl = if (path.startsWith("http")) path else "$cdn$path")
            }
        }.mapIndexed { index, page -> Page(index, page.url, page.imageUrl) }
    }

    private suspend fun fetchDetails(type: String, id: String): SManga? {
        return client.get("$baseUrl/api/public/$type/$id").use { response ->
            val data = response.parseAs<SeriesDetailResponse>()
            SManga.create().apply {
                url = "$type/$id/${data.slug.orEmpty()}"
                title = data.title.orEmpty()
                thumbnail_url = data.coverImageApp?.card?.mobile
                    ?: data.coverImageApp?.desktop
                    ?: data.coverImage
                author = data.author
                artist = data.artist
                description = data.synopsis ?: data.description
                status = when (data.status?.lowercase()) {
                    "ongoing", "مستمر" -> SManga.ONGOING
                    "completed", "مكتمل" -> SManga.COMPLETED
                    "hiatus" -> SManga.ON_HIATUS
                    else -> SManga.UNKNOWN
                }
                initialized = true
            }
        }
    }

    private suspend fun fetchChapters(type: String, id: String): List<SChapter> {
        val url = "$baseUrl/api/public/$type/$id/chapters".toHttpUrl().newBuilder()
            .addQueryParameter("page", "1")
            .addQueryParameter("limit", "500")
            .addQueryParameter("order", "desc")
            .build()

        return client.get(url).use { response ->
            response.parseAs<ChaptersResponse>().data.map { ch ->
                SChapter.create().apply {
                    url = "$type/$id/${ch.id}/${ch.chapterNumber}"
                    name = "الفصل ${ch.chapterNumber}" +
                        if (!ch.title.isNullOrBlank()) " - ${ch.title}" else ""
                    date_upload = runCatching { Instant.parse(ch.publishedAt.orEmpty()).toEpochMilli() }.getOrDefault(0L)
                    chapter_number = ch.chapterNumber.toFloatOrNull() ?: 0f
                    scanlator = if (ch.lockedByCoins == true) "🔒 مدفوع" else null
                }
            }
        }
    }
}

@Serializable
private class LatestUpdatesResponse(
    val success: Boolean = true,
    val data: List<SeriesDto> = emptyList(),
)

@Serializable
private class SeriesDto(
    @SerialName("manga_id") val mangaId: Int? = null,
    @SerialName("manga_slug") val mangaSlug: String? = null,
    @SerialName("manga_title") val mangaTitle: String? = null,
    @SerialName("cover_image") val coverImage: String? = null,
    val type: String? = null,
    @SerialName("cover_image_app") val coverImageApp: CoverImageApp? = null,
) {
    fun toSManga() = SManga.create().apply {
        url = "${type ?: "manga"}/${mangaId ?: 0}/${mangaSlug.orEmpty()}"
        title = mangaTitle.orEmpty()
        thumbnail_url = coverImageApp?.card?.mobile ?: coverImageApp?.desktop ?: coverImage
    }
}

@Serializable
private class CoverImageApp(
    val desktop: String? = null,
    val card: CardImages? = null,
)

@Serializable
private class CardImages(
    val mobile: String? = null,
    val desktop: String? = null,
)

@Serializable
private class SeriesDetailResponse(
    val id: Int? = null,
    val title: String? = null,
    val slug: String? = null,
    @SerialName("cover_image") val coverImage: String? = null,
    @SerialName("cover_image_app") val coverImageApp: CoverImageApp? = null,
    val author: String? = null,
    val artist: String? = null,
    val description: String? = null,
    val synopsis: String? = null,
    val status: String? = null,
)

@Serializable
private class ChaptersResponse(
    val data: List<ChapterDto> = emptyList(),
    val total: Int? = null,
)

@Serializable
private class ChapterDto(
    val id: Int = 0,
    @SerialName("chapter_number") val chapterNumber: String? = null,
    val title: String? = null,
    @SerialName("published_at") val publishedAt: String? = null,
    val lockedByCoins: Boolean? = null,
    @SerialName("cdn_path") val cdnPath: String? = null,
    val metadata: ChapterMetadataDto? = null,
)

@Serializable
private class ChapterMetadataDto(
    val images: List<String> = emptyList(),
)
